package com.TechMService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechMServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechMServiceApplication.class, args);
	}

}
