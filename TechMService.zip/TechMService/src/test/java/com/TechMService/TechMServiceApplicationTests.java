package com.TechMService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechMServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
